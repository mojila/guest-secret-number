PROMPT Space consumption before compression
COLUMN partition_name FORMAT a50
COLUMN segment_name FORMAT a50

SET ECHO ON

SELECT partition_name, compression 
FROM   user_tab_partitions
WHERE  partition_name='SALES_Q4_2001';

SELECT segment_name, bytes/(1024*1024) MB 
FROM   user_segments
WHERE  segment_name='SALES' AND partition_name='SALES_Q4_2001';

SET ECHO OFF
