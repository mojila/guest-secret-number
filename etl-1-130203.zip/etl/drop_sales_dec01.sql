DROP TABLE sales_dec01;
