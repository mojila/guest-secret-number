ALTER TABLE sales ADD CONSTRAINT sales_pk
  PRIMARY KEY (prod_id, cust_id, promo_id, channel_id, time_id) 
  USING INDEX;