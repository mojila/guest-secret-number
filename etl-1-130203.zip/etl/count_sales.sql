PROMPT   show the actual content of the partition to be aged out AFTER exchange
Rem   no more data in it
SELECT COUNT(*) 
FROM   sales PARTITION (sales_q1_1998);

SELECT COUNT(*) 
FROM   sales_old_q1_1998;
