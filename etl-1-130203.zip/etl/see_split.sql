COL segment_name format a25
COL partition_name format a25
COL tablespace_name format a25

Rem you will see that the newly created index segments 
Rem are co-located with the table partitions

Rem Also note the automatically derived naming
SELECT segment_name, partition_name, tablespace_name 
FROM   user_segments
WHERE  segment_type='INDEX PARTITION'
AND segment_name IN 
  (SELECT index_name 
   FROM   user_indexes 
   WHERE  table_name='SALES');