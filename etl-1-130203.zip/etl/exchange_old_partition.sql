SET ECHO ON
Rem   *****
PROMPT   EXCHANGE IT TO "REMOVE" OLD DATA
Rem   the exchange happens in a fraction of seconds, 
Rem   since it is only a DDL command
Rem   *****

ALTER TABLE sales 
  EXCHANGE PARTITION sales_q1_1998 
  WITH TABLE sales_old_q1_1998 
  INCLUDING INDEXES;
