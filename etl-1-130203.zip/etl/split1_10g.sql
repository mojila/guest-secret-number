Rem ***10g*** 
PROMPT We now want to leverage the new functionality and break down the existing
PROMPT quarter partition into monthly ones, leveraging new 10g functionality

Rem note that we haven't specified an index location, so they will be colocated with the partitions.
Rem the name will be inherited by the partition name

ALTER TABLE sales SPLIT PARTITION sales_q1_2002
AT (TO_DATE('01-MAR-2002','DD-MON-YYYY'))
INTO (PARTITION sales_1_2_2002 TABLESPACE example, 
PARTITION sales_MAR_2002 TABLESPACE example NOCOMPRESS)
UPDATE INDEXES;