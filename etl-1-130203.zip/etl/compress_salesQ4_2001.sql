PROMPT now compress the partition including index maintenance (details later))

ALTER TABLE sales MOVE PARTITION sales_q4_2001 COMPRESS UPDATE INDEXES;
