PROMPT   show the actual content of the partition to be aged out BEFORE exchange

SELECT COUNT(*) 
FROM   sales PARTITION (sales_q1_1998);
